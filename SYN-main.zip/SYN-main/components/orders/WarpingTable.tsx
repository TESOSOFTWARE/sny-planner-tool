"use client";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { generateWarpingBeams } from "@/data/warping_template";
import { toVN } from "@/lib/formatters";
import type { WarpingBeam } from "@/types";

const POS_COLORS: Record<WarpingBeam["viTri"], string> = {
  TRƯỚC: "bg-sky-50 text-sky-700 border-sky-200",
  GIỮA:  "bg-violet-50 text-violet-700 border-violet-200",
  SAU:   "bg-amber-50 text-amber-700 border-amber-200",
};

interface Props {
  color: string;
}

export function WarpingTable({ color }: Props) {
  const beams = generateWarpingBeams(color);

  return (
    <div className="rounded-lg border border-slate-200 bg-white overflow-hidden">
      <div className="px-4 py-3 border-b border-slate-100 bg-slate-50">
        <h3 className="text-sm font-semibold text-slate-700">
          Phiếu Warping — {beams.length} bim
        </h3>
      </div>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="bg-slate-50 text-xs">
              <TableHead className="w-10 font-semibold text-slate-600">No</TableHead>
              <TableHead className="font-semibold text-slate-600">Denier</TableHead>
              <TableHead className="font-semibold text-slate-600">Strand</TableHead>
              <TableHead className="font-semibold text-slate-600">Màu</TableHead>
              <TableHead className="font-semibold text-slate-600 text-right">Số máy</TableHead>
              <TableHead className="font-semibold text-slate-600 text-right">Số bim</TableHead>
              <TableHead className="font-semibold text-slate-600 text-right">Bim</TableHead>
              <TableHead className="font-semibold text-slate-600 text-right">Nặng (kg)</TableHead>
              <TableHead className="font-semibold text-slate-600">Vị trí</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {beams.map((beam) => (
              <TableRow key={beam.no} className="hover:bg-slate-50 text-sm">
                <TableCell className="font-mono text-slate-500">{beam.no}</TableCell>
                <TableCell className="font-mono">{beam.denier}</TableCell>
                <TableCell className="font-mono">{beam.strand}</TableCell>
                <TableCell className="font-mono text-slate-700">{beam.color}</TableCell>
                <TableCell className="text-right font-mono">{beam.soMay}</TableCell>
                <TableCell className="text-right font-mono">{beam.soBim}</TableCell>
                <TableCell className="text-right font-mono">{beam.bim}</TableCell>
                <TableCell className="text-right font-mono">{toVN(beam.weightKg, 1)}</TableCell>
                <TableCell>
                  <span
                    className={`inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium ${POS_COLORS[beam.viTri]}`}
                  >
                    {beam.viTri}
                  </span>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
