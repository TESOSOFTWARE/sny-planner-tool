"use client";

import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import type { Order, OrderStatus } from "@/types";
import { toVNDate, toVN } from "@/lib/formatters";
import { Eye } from "lucide-react";

function StatusBadge({ status }: { status: OrderStatus }) {
  const map: Record<OrderStatus, string> = {
    "Đang sản xuất": "bg-emerald-100 text-emerald-800 border-emerald-200",
    "Đã duyệt":       "bg-sky-100 text-sky-800 border-sky-200",
    "Chờ duyệt":      "bg-amber-100 text-amber-800 border-amber-200",
  };
  return (
    <span
      className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium ${map[status]}`}
    >
      {status}
    </span>
  );
}

interface Props {
  orders: Order[];
}

export function OrderTable({ orders }: Props) {
  return (
    <div className="rounded-lg border border-slate-200 bg-white overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow className="bg-slate-50">
            <TableHead className="font-semibold text-slate-600 w-40">Mã đơn</TableHead>
            <TableHead className="font-semibold text-slate-600">Khách</TableHead>
            <TableHead className="font-semibold text-slate-600 max-w-xs">Quy cách</TableHead>
            <TableHead className="font-semibold text-slate-600 text-right">Số mét</TableHead>
            <TableHead className="font-semibold text-slate-600">Hạn giao</TableHead>
            <TableHead className="font-semibold text-slate-600">Trạng thái</TableHead>
            <TableHead className="w-16"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {orders.map((order) => (
            <TableRow key={order.id} className="hover:bg-slate-50 transition-colors">
              <TableCell className="font-mono text-sm font-medium text-slate-800">
                {order.id}
              </TableCell>
              <TableCell className="text-slate-700">{order.customer}</TableCell>
              <TableCell className="max-w-xs">
                <span className="text-xs font-mono text-slate-500 truncate block">
                  {order.specRaw}
                </span>
              </TableCell>
              <TableCell className="text-right font-mono text-slate-700">
                {toVN(order.meters)}
              </TableCell>
              <TableCell className="text-slate-700">{toVNDate(order.deadline)}</TableCell>
              <TableCell>
                <StatusBadge status={order.status} />
              </TableCell>
              <TableCell>
                <Link href={`/orders/${encodeURIComponent(order.id)}`}>
                  <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-slate-500 hover:text-slate-900">
                    <Eye size={15} />
                  </Button>
                </Link>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
