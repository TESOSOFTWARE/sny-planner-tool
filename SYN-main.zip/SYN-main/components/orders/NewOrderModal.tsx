"use client";

import { useState, useRef } from "react";
import { useRouter } from "next/navigation";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { parseSpec } from "@/lib/parseSpec";
import { useOrders } from "@/lib/orderContext";
import type { ParsedSpec } from "@/types";

interface Props {
  open: boolean;
  onClose: () => void;
}

function SpecBadges({ spec }: { spec: ParsedSpec }) {
  const items: { label: string; value: string | number | null }[] = [
    { label: "GSM",       value: spec.gsm },
    { label: "Màu",       value: spec.color },
    { label: "Khổ",       value: spec.width != null ? `${spec.width} m` : null },
    { label: "Dài cuộn",  value: spec.length != null ? `${spec.length} m` : null },
    { label: "Số cuộn",   value: spec.rolls },
    { label: "Loại lưới", value: spec.fabricType !== "Unknown" ? spec.fabricType : null },
    { label: "%FR",       value: spec.fr != null ? `${spec.fr}%` : null },
    { label: "%UV",       value: spec.uv != null ? `${spec.uv}%` : null },
  ];

  const visible = items.filter((i) => i.value !== null && i.value !== "");

  if (visible.length === 0) return null;

  return (
    <div className="flex flex-wrap gap-2 mt-3 p-3 rounded-md bg-slate-50 border border-slate-200">
      {visible.map(({ label, value }) => (
        <div key={label} className="flex items-center gap-1">
          <span className="text-xs text-slate-500 font-medium">{label}:</span>
          <Badge variant="secondary" className="text-xs font-mono">
            {String(value)}
          </Badge>
        </div>
      ))}
    </div>
  );
}

export function NewOrderModal({ open, onClose }: Props) {
  const router = useRouter();
  const { addOrder, orders } = useOrders();

  const [specRaw, setSpecRaw] = useState("");
  const [customer, setCustomer] = useState("");
  const [deadline, setDeadline] = useState("");

  const parsed = parseSpec(specRaw);
  const hasSpec = specRaw.trim().length > 0;

  function handleSave() {
    if (!specRaw.trim() || !deadline) return;

    // Store the new order and grab the latest ID from the state
    addOrder(specRaw, customer, deadline);

    // Navigate to the most recently added order (it will be first in the array)
    // We need a small delay for state to update, then navigate
    setTimeout(() => {
      // Access the orders through the context — the new one will be first
      const all = orders;
      if (all.length > 0) {
        // Find by timestamp pattern NEW-
        const newOrder = all.find((o) => o.id.startsWith("NEW-"));
        if (newOrder) {
          router.push(`/orders/${encodeURIComponent(newOrder.id)}`);
        }
      }
    }, 50);

    onClose();
    setSpecRaw("");
    setCustomer("");
    setDeadline("");
  }

  function handleClose() {
    onClose();
    setSpecRaw("");
    setCustomer("");
    setDeadline("");
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && handleClose()}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-slate-800">Tạo lệnh sản xuất mới</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* Customer */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Tên khách hàng
            </label>
            <Input
              id="modal-customer"
              placeholder="Ví dụ: FABO, GBN (Garbinox)…"
              value={customer}
              onChange={(e) => setCustomer(e.target.value)}
            />
          </div>

          {/* Spec textarea */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Dán quy cách sản phẩm từ Excel
            </label>
            <Textarea
              id="modal-spec"
              placeholder="Ví dụ: 220GSM DGREEN 4008 6MX100M 84ROLLS"
              className="font-mono text-sm resize-none h-24"
              value={specRaw}
              onChange={(e) => setSpecRaw(e.target.value)}
            />
            {/* Live parsed badges */}
            {hasSpec && <SpecBadges spec={parsed} />}
          </div>

          {/* Deadline */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Hạn giao hàng
            </label>
            <Input
              id="modal-deadline"
              type="date"
              value={deadline}
              onChange={(e) => setDeadline(e.target.value)}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose}>
            Hủy
          </Button>
          <Button
            onClick={handleSave}
            disabled={!specRaw.trim() || !deadline}
            className="bg-emerald-600 hover:bg-emerald-700 text-white"
          >
            Lưu lệnh sản xuất
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
