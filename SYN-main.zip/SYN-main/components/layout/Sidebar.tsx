"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ClipboardList, CalendarDays, Package } from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "/orders",    label: "Lệnh sản xuất", icon: ClipboardList },
  { href: "/schedule",  label: "Lịch máy",       icon: CalendarDays },
  { href: "/materials", label: "Nguyên liệu",     icon: Package },
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="flex h-screen w-56 flex-col border-r border-slate-200 bg-slate-900 text-slate-100 fixed left-0 top-0 z-40">
      {/* Logo */}
      <div className="flex items-center gap-2 px-5 py-5 border-b border-slate-700">
        <div className="w-8 h-8 rounded-md bg-emerald-500 flex items-center justify-center">
          <span className="text-white font-bold text-sm">S</span>
        </div>
        <span className="font-semibold text-base tracking-wide text-white">SNY Planner</span>
      </div>

      {/* Nav */}
      <nav className="flex-1 py-4 px-3 space-y-1">
        {navItems.map(({ href, label, icon: Icon }) => {
          const active = pathname === href || pathname.startsWith(href + "/");
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                "flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium transition-colors",
                active
                  ? "bg-emerald-600 text-white"
                  : "text-slate-400 hover:bg-slate-800 hover:text-white"
              )}
            >
              <Icon size={17} />
              {label}
            </Link>
          );
        })}
      </nav>

      {/* Footer tag */}
      <div className="px-5 py-3 border-t border-slate-700">
        <p className="text-xs text-slate-500">Demo v0.1 — SNY Factory</p>
      </div>
    </aside>
  );
}
