"use client";

import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface TopbarProps {
  title: string;
}

export function Topbar({ title }: TopbarProps) {
  return (
    <header className="h-14 flex items-center justify-between px-6 border-b border-slate-200 bg-white sticky top-0 z-30">
      <h1 className="text-lg font-semibold text-slate-800">{title}</h1>
      <div className="flex items-center gap-3">
        <div className="text-right">
          <p className="text-sm font-medium text-slate-800 leading-none">Dung</p>
          <p className="text-xs text-slate-500 mt-0.5">Kế hoạch SX</p>
        </div>
        <Avatar className="h-9 w-9">
          <AvatarFallback className="bg-emerald-100 text-emerald-700 font-semibold text-sm">
            DK
          </AvatarFallback>
        </Avatar>
      </div>
    </header>
  );
}
