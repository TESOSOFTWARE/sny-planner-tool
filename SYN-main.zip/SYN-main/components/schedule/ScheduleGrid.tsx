"use client";

import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import type { Machine, ScheduleRevision, ScheduleCell, FabricType } from "@/types";

// ─── Color palette by fabric type ────────────────────────────────────────────

const FABRIC_COLORS: Record<FabricType, { bg: string; border: string; text: string }> = {
  "Shade Net":   { bg: "bg-emerald-100", border: "border-emerald-300", text: "text-emerald-900" },
  "Windbreak":   { bg: "bg-violet-100",  border: "border-violet-300",  text: "text-violet-900"  },
  "Rectangular": { bg: "bg-sky-100",     border: "border-sky-300",     text: "text-sky-900"      },
  "Fence":       { bg: "bg-orange-100",  border: "border-orange-300",  text: "text-orange-900"   },
  "Leaf Net":    { bg: "bg-lime-100",    border: "border-lime-300",    text: "text-lime-900"     },
  "Unknown":     { bg: "bg-slate-100",   border: "border-slate-300",   text: "text-slate-700"    },
};

const DAYS = Array.from({ length: 31 }, (_, i) => i + 1);

// ─── Cell block ───────────────────────────────────────────────────────────────

function CellBlock({ cell }: { cell: ScheduleCell }) {
  const colors = FABRIC_COLORS[cell.fabricType];
  const [orderCode, ...rest] = cell.label.split("\n");

  return (
    <Tooltip>
      <TooltipTrigger
        className={`
          block w-full rounded border px-1.5 py-1 text-left cursor-default
          ${colors.bg} ${colors.border} ${colors.text}
        `}
      >
        <p className="font-semibold font-mono text-[10px] leading-tight truncate">
          {orderCode}
        </p>
        {rest.length > 0 && (
          <p className="text-[9px] leading-tight truncate opacity-80 mt-0.5">
            {rest.join(" ")}
          </p>
        )}
      </TooltipTrigger>
      <TooltipContent side="bottom" className="max-w-xs text-xs">
        <p className="font-mono whitespace-pre-wrap">{cell.tooltip}</p>
      </TooltipContent>
    </Tooltip>
  );
}

// ─── Main grid ────────────────────────────────────────────────────────────────

interface Props {
  revision: ScheduleRevision;
  machines: Machine[];
}

export function ScheduleGrid({ revision, machines }: Props) {
  // Build a lookup: machineId → cells for this revision
  const rowMap = new Map(revision.rows.map((r) => [r.machineId, r.cells]));

  // Group machines by width for left-edge labels
  const widthGroups = machines.reduce<Map<number, Machine[]>>((acc, m) => {
    const g = acc.get(m.width) ?? [];
    g.push(m);
    acc.set(m.width, g);
    return acc;
  }, new Map());

  return (
    <div className="rounded-xl border border-slate-200 bg-white overflow-hidden shadow-sm">
      {/* Legend */}
      <div className="flex items-center gap-4 px-4 py-3 border-b border-slate-100 bg-slate-50 flex-wrap">
        <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide mr-2">
          Chú thích:
        </span>
        {(Object.entries(FABRIC_COLORS) as [FabricType, typeof FABRIC_COLORS[FabricType]][])
          .filter(([type]) => type !== "Unknown")
          .map(([type, colors]) => (
            <div key={type} className="flex items-center gap-1.5">
              <div className={`w-3 h-3 rounded border ${colors.bg} ${colors.border}`} />
              <span className="text-xs text-slate-600">{type}</span>
            </div>
          ))}
      </div>

      {/* Scrollable grid */}
      <div className="overflow-x-auto">
        <div style={{ minWidth: "calc(31 * 68px + 220px)" }}>
          {/* Header row: day numbers */}
          <div className="flex border-b border-slate-200 bg-slate-50 sticky top-0 z-10">
            {/* Fixed left header */}
            <div className="flex-shrink-0 w-[220px] border-r border-slate-200 px-3 py-2">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
                Máy / Khổ
              </span>
            </div>
            {/* Day columns */}
            {DAYS.map((d) => (
              <div
                key={d}
                className="flex-shrink-0 w-[68px] border-r border-slate-100 text-center py-2"
              >
                <span className="text-xs font-semibold text-slate-600">{d}</span>
              </div>
            ))}
          </div>

          {/* Machine rows */}
          {machines.map((machine) => {
            const cells = rowMap.get(machine.id) ?? [];

            // Build a map from day → which cells overlap it
            const dayCells = new Map<number, ScheduleCell[]>();
            DAYS.forEach((d) => {
              const overlapping = cells.filter(
                (c) => d >= c.dayStart && d <= c.dayEnd
              );
              if (overlapping.length > 0) dayCells.set(d, overlapping);
            });

            return (
              <div
                key={machine.id}
                className="flex border-b border-slate-100 hover:bg-slate-50 group"
                style={{ minHeight: "56px" }}
              >
                {/* Machine label */}
                <div className="flex-shrink-0 w-[220px] border-r border-slate-200 px-3 py-2 flex flex-col justify-center">
                  <p className="font-semibold text-sm text-slate-800">{machine.name}</p>
                  <p className="text-xs text-slate-400 mt-0.5">Khổ {machine.width} m</p>
                </div>

                {/* Day cells */}
                {DAYS.map((d) => {
                  const cellsHere = dayCells.get(d);
                  const isStart = cellsHere?.some((c) => c.dayStart === d);
                  const isEnd = cellsHere?.some((c) => c.dayEnd === d);

                  return (
                    <div
                      key={d}
                      className="flex-shrink-0 w-[68px] border-r border-slate-100 p-1 flex flex-col gap-1 justify-center"
                    >
                      {isStart
                        ? cellsHere!.map((cell) => (
                            <CellBlock key={`${cell.orderId}-${d}`} cell={cell} />
                          ))
                        : cellsHere && !isStart
                        ? cellsHere.map((cell) => (
                            // Continuation — show a thin colored bar
                            <div
                              key={`${cell.orderId}-cont-${d}`}
                              className={`h-6 rounded border ${FABRIC_COLORS[cell.fabricType].bg} ${FABRIC_COLORS[cell.fabricType].border} opacity-70`}
                            />
                          ))
                        : null}
                    </div>
                  );
                })}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
