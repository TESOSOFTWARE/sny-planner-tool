"use client";

import { Button } from "@/components/ui/button";
import { AlertTriangle, CheckCircle2 } from "lucide-react";

export function AlertCard() {
  return (
    <div className="rounded-xl border border-amber-200 bg-amber-50 p-5">
      {/* Header */}
      <div className="flex items-start gap-3 mb-4">
        <AlertTriangle className="text-amber-600 mt-0.5 flex-shrink-0" size={22} />
        <div>
          <h2 className="font-semibold text-amber-900 text-base">
            Cảnh báo nguyên liệu — 14 ngày tới
          </h2>
          <p className="text-sm text-amber-700 mt-0.5">
            Dựa trên 8 đơn hàng đang lên kế hoạch sản xuất, hệ thống dự báo:
          </p>
        </div>
      </div>

      {/* Alert lines */}
      <ul className="space-y-2.5 mb-5 pl-8">
        <li className="flex items-start gap-2">
          <AlertTriangle className="text-red-500 mt-0.5 flex-shrink-0" size={14} />
          <span className="text-sm text-slate-800">
            Thiếu <span className="font-semibold font-mono">157 kg</span> MB BEIGE NHẠT (3160-2)
            {" "}— cần đặt trước{" "}
            <span className="font-semibold text-red-700">thứ Tư 7/1</span>
          </span>
        </li>
        <li className="flex items-start gap-2">
          <AlertTriangle className="text-red-500 mt-0.5 flex-shrink-0" size={14} />
          <span className="text-sm text-slate-800">
            Thiếu <span className="font-semibold font-mono">312 kg</span> MB BEIGE ĐẬM (3233-5)
            {" "}— cần đặt trước{" "}
            <span className="font-semibold text-red-700">thứ Sáu 9/1</span>
          </span>
        </li>
        <li className="flex items-start gap-2">
          <CheckCircle2 className="text-emerald-600 mt-0.5 flex-shrink-0" size={14} />
          <span className="text-sm text-slate-800">
            Đủ MB SWHITE — tồn{" "}
            <span className="font-semibold font-mono">1.065 kg</span>, cần{" "}
            <span className="font-mono">540 kg</span>
          </span>
        </li>
      </ul>

      {/* Actions */}
      <div className="flex gap-3 pl-8">
        <Button
          id="btn-view-detail"
          variant="outline"
          size="sm"
          className="border-amber-300 text-amber-800 hover:bg-amber-100"
        >
          Xem chi tiết
        </Button>
        <Button
          id="btn-export-purchase"
          size="sm"
          className="bg-amber-600 hover:bg-amber-700 text-white"
        >
          Xuất đề xuất mua hàng
        </Button>
      </div>
    </div>
  );
}
