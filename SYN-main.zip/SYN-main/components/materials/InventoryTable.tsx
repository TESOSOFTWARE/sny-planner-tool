"use client";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import type { InventoryItem } from "@/types";
import { toVN } from "@/lib/formatters";

interface Props {
  items: InventoryItem[];
}

export function InventoryTable({ items }: Props) {
  return (
    <div className="rounded-lg border border-slate-200 bg-white overflow-hidden">
      <div className="px-4 py-3 border-b border-slate-100 bg-slate-50">
        <h3 className="text-sm font-semibold text-slate-700">
          Tồn kho nguyên liệu — {items.length} mặt hàng
        </h3>
      </div>
      <Table>
        <TableHeader>
          <TableRow className="bg-slate-50 text-xs">
            <TableHead className="font-semibold text-slate-600 w-28">Mã</TableHead>
            <TableHead className="font-semibold text-slate-600">Tên</TableHead>
            <TableHead className="font-semibold text-slate-600">Loại</TableHead>
            <TableHead className="font-semibold text-slate-600 text-right">Tồn kho (kg)</TableHead>
            <TableHead className="font-semibold text-slate-600 text-right">Đã cam kết (kg)</TableHead>
            <TableHead className="font-semibold text-slate-600 text-right">Còn lại (kg)</TableHead>
            <TableHead className="font-semibold text-slate-600 text-right">Cần đặt (kg)</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {items.map((item) => {
            const remaining = item.stock - item.committed;
            const shortage = Math.max(0, -remaining);
            const isShort = remaining < 0;

            return (
              <TableRow
                key={item.code}
                className={
                  isShort
                    ? "bg-red-50 hover:bg-red-100"
                    : "hover:bg-slate-50"
                }
              >
                <TableCell className="font-mono text-sm font-medium text-slate-700">
                  {item.code}
                </TableCell>
                <TableCell className="text-sm text-slate-800">{item.name}</TableCell>
                <TableCell className="text-sm text-slate-500">{item.type}</TableCell>
                <TableCell className="text-right font-mono text-sm">
                  {toVN(item.stock)}
                </TableCell>
                <TableCell className="text-right font-mono text-sm">
                  {toVN(item.committed)}
                </TableCell>
                <TableCell
                  className={`text-right font-mono text-sm font-semibold ${
                    isShort ? "text-red-700" : "text-slate-700"
                  }`}
                >
                  {toVN(Math.abs(remaining))}
                  {isShort && " ⚠"}
                </TableCell>
                <TableCell
                  className={`text-right font-mono text-sm font-semibold ${
                    shortage > 0 ? "text-red-700" : "text-slate-400"
                  }`}
                >
                  {shortage > 0 ? toVN(shortage) : "—"}
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}
