import type { Machine } from "@/types";

export const machines: Machine[] = [
  { id: 1,  name: "Máy 1",  width: 6.85 },
  { id: 2,  name: "Máy 2",  width: 6.56 },
  { id: 3,  name: "Máy 3",  width: 6.85 },
  { id: 4,  name: "Máy 4",  width: 6.56 },
  { id: 5,  name: "Máy 5",  width: 6.85 },
  { id: 7,  name: "Máy 7",  width: 6.56 },
  { id: 8,  name: "Máy 8",  width: 6.85 },
  { id: 11, name: "Máy 11", width: 6.85 },
  { id: 13, name: "Máy 13", width: 6.85 },
  { id: 14, name: "Máy 14", width: 6.56 },
  { id: 19, name: "Máy 19", width: 1.6  },
  { id: 21, name: "Máy 21", width: 1.6  },
];
