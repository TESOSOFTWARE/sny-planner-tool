// Real spec strings from the factory floor — used for parser tests and demo
export const REAL_SPECS = [
  "220GSM DGREEN 4008 6MX100M 84ROLLS",
  "170GSM SWHITE 1.6MX100M 85ROLLS (390 needles) 2LINE",
  "95GSM WHITE 6.5%FR+2%UV 3MX50M 400ROLLS 3LINE",
  "240GSM SNOW WHITE 4.5MX100M 38ROLLS (Single line Black double thread)",
] as const;
