import type { WarpingBeam } from "@/types";

// Template for a typical warping work order — 18 beams
// Alternating positions: TRƯỚC (front) / GIỮA (middle) / SAU (back)
// Denier values and strand counts are realistic for SNY production

const POSITIONS: ("TRƯỚC" | "GIỮA" | "SAU")[] = ["TRƯỚC", "GIỮA", "SAU"];
const DENIERS = [14.5, 18.5, 20, 14.5, 18.5, 20];

export function generateWarpingBeams(
  color: string,
  totalBeams = 18
): WarpingBeam[] {
  const beams: WarpingBeam[] = [];
  for (let i = 0; i < totalBeams; i++) {
    const pos = POSITIONS[i % 3];
    const denier = DENIERS[i % DENIERS.length];
    const strand = pos === "TRƯỚC" ? 144 : pos === "GIỮA" ? 128 : 112;
    const soMay = pos === "TRƯỚC" ? 6 : pos === "GIỮA" ? 5 : 4;
    const soBim = Math.floor(strand / 16);
    const bim = 16;
    const weightKg = +(denier * strand * 0.0055 + 1.2).toFixed(1);

    beams.push({
      no: i + 1,
      denier,
      strand,
      color,
      soMay,
      soBim,
      bim,
      weightKg,
      viTri: pos,
    });
  }
  return beams;
}
