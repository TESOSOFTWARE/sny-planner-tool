import type { Order } from "@/types";
import { parseSpec } from "@/lib/parseSpec";

const raw: Omit<Order, "spec">[] = [
  {
    id: "FABO25044A",
    customer: "FABO",
    specRaw: "220GSM DGREEN 4008 6MX100M 84ROLLS",
    meters: 8400,
    deadline: "2026-01-20",
    status: "Đang sản xuất",
  },
  {
    id: "FABO25045",
    customer: "FABO",
    specRaw: "220GSM DGREEN 4008 6MX100M 84ROLLS",
    meters: 8400,
    deadline: "2026-01-25",
    status: "Đang sản xuất",
  },
  {
    id: "GBN26-022",
    customer: "GBN (Garbinox)",
    specRaw: "95GSM WHITE 6.5%FR+2%UV 3MX50M 400ROLLS 3LINE",
    meters: 20000,
    deadline: "2026-01-15",
    status: "Đang sản xuất",
  },
  {
    id: "HSIA26-1",
    customer: "HSIA",
    specRaw: "170GSM SWHITE 1.6MX100M 85ROLLS (390 needles) 2LINE",
    meters: 8500,
    deadline: "2026-02-05",
    status: "Đã duyệt",
  },
  {
    id: "KSSNY194R1",
    customer: "KSSNY",
    specRaw: "240GSM SNOW WHITE 4.5MX100M 38ROLLS (Single line Black double thread)",
    meters: 3800,
    deadline: "2026-02-10",
    status: "Đã duyệt",
  },
  {
    id: "ORCHARDCOVER26-1",
    customer: "ORCHARDCOVER",
    specRaw: "240GSM DARK GREEN 2.3MX100M 120ROLLS WINDBREAK",
    meters: 12000,
    deadline: "2026-02-20",
    status: "Đã duyệt",
  },
  {
    id: "ALNAIMI26-1",
    customer: "ALNAIMI",
    specRaw: "60GSM DGREEN 2MX50M 330ROLLS",
    meters: 16500,
    deadline: "2026-03-01",
    status: "Chờ duyệt",
  },
  {
    id: "ITP26-1",
    customer: "ITP",
    specRaw: "55GSM SWHITE FR 3MX50M 176ROLLS",
    meters: 8800,
    deadline: "2026-03-10",
    status: "Chờ duyệt",
  },
];

export const initialOrders: Order[] = raw.map((o) => ({
  ...o,
  spec: parseSpec(o.specRaw),
}));
