import type { InventoryItem } from "@/types";

export const inventory: InventoryItem[] = [
  {
    code: "SWHITE",
    name: "MB SWHITE",
    type: "Masterbatch",
    stock: 1065,
    committed: 540,
  },
  {
    code: "3160-2",
    name: "MB BEIGE NHẠT (3160-2)",
    type: "Masterbatch",
    stock: 220,
    committed: 377,
  },
  {
    code: "3233-5",
    name: "MB BEIGE ĐẬM (3233-5)",
    type: "Masterbatch",
    stock: 280,
    committed: 592,
  },
  {
    code: "8005A",
    name: "MB BEIGE ĐẬM TAPE (8005A)",
    type: "Tape",
    stock: 600,
    committed: 240,
  },
  {
    code: "9175-2",
    name: "MB TERRACOTA (9175-2)",
    type: "Masterbatch",
    stock: 150,
    committed: 145,
  },
  {
    code: "3232-3",
    name: "MB IVORY (3232-3)",
    type: "Masterbatch",
    stock: 410,
    committed: 65,
  },
  {
    code: "8086-2",
    name: "MB GREEN (8086-2)",
    type: "Masterbatch",
    stock: 132,
    committed: 58,
  },
  {
    code: "2032-2",
    name: "MB STEEL GREY (2032-2)",
    type: "Masterbatch",
    stock: 318,
    committed: 130,
  },
  {
    code: "6026-1",
    name: "MB AQUA BLUE (6026-1)",
    type: "Masterbatch",
    stock: 250,
    committed: 80,
  },
  {
    code: "432-2",
    name: "MB GUNMETAL (432-2)",
    type: "Masterbatch",
    stock: 200,
    committed: 100,
  },
];
