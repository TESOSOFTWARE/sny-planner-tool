import type { ScheduleRevision, FabricType } from "@/types";

function cell(
  orderId: string,
  label: string,
  tooltip: string,
  fabricType: FabricType,
  dayStart: number,
  dayEnd: number
) {
  return { orderId, label, tooltip, fabricType, dayStart, dayEnd };
}

// ─── Revision 5.1.2026 ───────────────────────────────────────────────────────

const rev5: ScheduleRevision = {
  version: "5.1.2026",
  label: "5/1/2026",
  rows: [
    {
      machineId: 1,
      cells: [
        cell(
          "FABO25045",
          "FABO25045\n220GSM DGREEN 6Mx100M",
          "FABO25045 — SHADE NET MONO / 220GSM DGREEN 4008 6MX100M 84ROLLS",
          "Shade Net",
          1,
          11
        ),
        cell(
          "HSIA26-1",
          "HSIA26-1\n55GSM WHITE 2.4Mx50M",
          "HSIA26-1 — RECTANGULAR NET 12WALE / 55GSM WHITE 2.4MX50M 710ROLLS",
          "Rectangular",
          12,
          25
        ),
      ],
    },
    {
      machineId: 2,
      cells: [
        cell(
          "GBN26-022",
          "GBN26-022\n95GSM YELLOW 3Mx50M",
          "GBN26-022 / 95GSM YELLOW 3MX50M 160ROLLS",
          "Shade Net",
          1,
          6
        ),
        cell(
          "25KG1201",
          "25KG1201\n56GSM DBLUE 3Mx50M",
          "25KG1201 / 56GSM DBLUE 3MX50M 248ROLLS",
          "Shade Net",
          7,
          12
        ),
        cell(
          "GBN26-022",
          "GBN26-022\n95GSM BLACK 3Mx50M",
          "GBN26-022 / 95GSM BLACK 3MX50M 250ROLLS",
          "Shade Net",
          13,
          19
        ),
      ],
    },
    {
      machineId: 3,
      cells: [
        cell(
          "KSSNY194R1",
          "KSSNY194R1\n40GSM BLACK 6.4Mx1500M",
          "KSSNY194R1 — LEAF NET / 40GSM BLACK 6.4MX1500M",
          "Leaf Net",
          1,
          14
        ),
        cell(
          "ORCHARDCOVER26-1",
          "ORCHARDCOVER26-1\n240GSM DK.GREEN 2.3Mx100M",
          "ORCHARDCOVER26-1 — KIWI WINDBREAK / 240GSM DARK GREEN 2.3MX100M",
          "Windbreak",
          15,
          23
        ),
      ],
    },
    {
      machineId: 4,
      cells: [
        cell(
          "ITP26-1",
          "ITP26-1\n55GSM SWHITE FR 3Mx50M",
          "ITP26-1 / 55GSM SWHITE FR 3MX50M 176ROLLS",
          "Shade Net",
          4,
          8
        ),
      ],
    },
    {
      machineId: 5,
      cells: [
        cell(
          "ALNAIMI26-1",
          "ALNAIMI26-1\n60% DGREEN 2Mx50M",
          "ALNAIMI26-1 / 60% DGREEN 2MX50M 330ROLLS",
          "Shade Net",
          2,
          9
        ),
      ],
    },
  ],
};

// ─── Revision 3.1.2026 ───────────────────────────────────────────────────────
// Slightly earlier plan — same machines, dates shifted by 1-2 days

const rev3: ScheduleRevision = {
  version: "3.1.2026",
  label: "3/1/2026",
  rows: [
    {
      machineId: 1,
      cells: [
        cell(
          "FABO25045",
          "FABO25045\n220GSM DGREEN 6Mx100M",
          "FABO25045 — SHADE NET MONO / 220GSM DGREEN 4008 6MX100M 84ROLLS",
          "Shade Net",
          1,
          13
        ),
        cell(
          "HSIA26-1",
          "HSIA26-1\n55GSM WHITE 2.4Mx50M",
          "HSIA26-1 — RECTANGULAR NET 12WALE / 55GSM WHITE 2.4MX50M 710ROLLS",
          "Rectangular",
          14,
          26
        ),
      ],
    },
    {
      machineId: 2,
      cells: [
        cell(
          "GBN26-022",
          "GBN26-022\n95GSM YELLOW 3Mx50M",
          "GBN26-022 / 95GSM YELLOW 3MX50M 160ROLLS",
          "Shade Net",
          1,
          7
        ),
        cell(
          "GBN26-022",
          "GBN26-022\n95GSM BLACK 3Mx50M",
          "GBN26-022 / 95GSM BLACK 3MX50M 250ROLLS",
          "Shade Net",
          8,
          20
        ),
      ],
    },
    {
      machineId: 3,
      cells: [
        cell(
          "KSSNY194R1",
          "KSSNY194R1\n40GSM BLACK 6.4Mx1500M",
          "KSSNY194R1 — LEAF NET / 40GSM BLACK 6.4MX1500M",
          "Leaf Net",
          1,
          16
        ),
        cell(
          "ORCHARDCOVER26-1",
          "ORCHARDCOVER26-1\n240GSM DK.GREEN 2.3Mx100M",
          "ORCHARDCOVER26-1 — KIWI WINDBREAK / 240GSM DARK GREEN 2.3MX100M",
          "Windbreak",
          17,
          25
        ),
      ],
    },
    {
      machineId: 4,
      cells: [
        cell(
          "ITP26-1",
          "ITP26-1\n55GSM SWHITE FR 3Mx50M",
          "ITP26-1 / 55GSM SWHITE FR 3MX50M 176ROLLS",
          "Shade Net",
          3,
          9
        ),
      ],
    },
    {
      machineId: 5,
      cells: [
        cell(
          "ALNAIMI26-1",
          "ALNAIMI26-1\n60% DGREEN 2Mx50M",
          "ALNAIMI26-1 / 60% DGREEN 2MX50M 330ROLLS",
          "Shade Net",
          1,
          10
        ),
      ],
    },
  ],
};

// ─── Revision 2.1.2026 ───────────────────────────────────────────────────────
// Earliest plan

const rev2: ScheduleRevision = {
  version: "2.1.2026",
  label: "2/1/2026",
  rows: [
    {
      machineId: 1,
      cells: [
        cell(
          "FABO25045",
          "FABO25045\n220GSM DGREEN 6Mx100M",
          "FABO25045 — SHADE NET MONO / 220GSM DGREEN 4008 6MX100M 84ROLLS",
          "Shade Net",
          1,
          15
        ),
      ],
    },
    {
      machineId: 2,
      cells: [
        cell(
          "GBN26-022",
          "GBN26-022\n95GSM YELLOW 3Mx50M",
          "GBN26-022 / 95GSM YELLOW 3MX50M 160ROLLS",
          "Shade Net",
          1,
          9
        ),
      ],
    },
    {
      machineId: 3,
      cells: [
        cell(
          "KSSNY194R1",
          "KSSNY194R1\n40GSM BLACK 6.4Mx1500M",
          "KSSNY194R1 — LEAF NET / 40GSM BLACK 6.4MX1500M",
          "Leaf Net",
          2,
          18
        ),
      ],
    },
    {
      machineId: 4,
      cells: [],
    },
    {
      machineId: 5,
      cells: [],
    },
  ],
};

export const scheduleRevisions: ScheduleRevision[] = [rev5, rev3, rev2];
