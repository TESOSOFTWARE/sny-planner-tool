"use client";

import { useState } from "react";
import { Topbar } from "@/components/layout/Topbar";
import { ScheduleGrid } from "@/components/schedule/ScheduleGrid";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { scheduleRevisions } from "@/data/schedule";
import { machines } from "@/data/machines";
import { Plus } from "lucide-react";

export default function SchedulePage() {
  const [versionIdx, setVersionIdx] = useState(0); // default: latest (5.1.2026)
  const [showPhaseModal, setShowPhaseModal] = useState(false);

  const activeRevision = scheduleRevisions[versionIdx];

  return (
    <>
      <Topbar title="Lịch máy dệt — Tháng 1/2026" />
      <main className="flex-1 p-6">
        <div className="max-w-full">
          {/* Controls bar */}
          <div className="flex items-center justify-between mb-5">
            <Button
              id="btn-publish-version"
              variant="outline"
              className="gap-2 text-slate-700"
              onClick={() => setShowPhaseModal(true)}
            >
              <Plus size={15} />
              Phát hành phiên bản mới
            </Button>

            <div className="flex items-center gap-2">
              <span className="text-sm text-slate-500">Phiên bản:</span>
              <Select
                value={String(versionIdx)}
                onValueChange={(v) => setVersionIdx(Number(v))}
              >
                <SelectTrigger id="select-version" className="w-36">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {scheduleRevisions.map((rev, i) => (
                    <SelectItem key={rev.version} value={String(i)}>
                      {rev.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* The grid */}
          <ScheduleGrid revision={activeRevision} machines={machines} />
        </div>
      </main>

      {/* Phase modal (no-op) */}
      <Dialog open={showPhaseModal} onOpenChange={setShowPhaseModal}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Phát hành phiên bản mới</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p className="text-sm text-slate-600 text-center">
              Tính năng đầy đủ sẽ có ở Phase 1
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
