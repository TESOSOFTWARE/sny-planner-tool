"use client";

import { useState } from "react";
import { Topbar } from "@/components/layout/Topbar";
import { OrderTable } from "@/components/orders/OrderTable";
import { NewOrderModal } from "@/components/orders/NewOrderModal";
import { useOrders } from "@/lib/orderContext";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

export default function OrdersPage() {
  const { orders } = useOrders();
  const [showModal, setShowModal] = useState(false);

  return (
    <>
      <Topbar title="Lệnh sản xuất" />
      <main className="flex-1 p-6">
        <div className="max-w-7xl mx-auto">
          {/* Page actions */}
          <div className="flex items-center justify-between mb-5">
            <div>
              <p className="text-sm text-slate-500">
                {orders.length} lệnh sản xuất
              </p>
            </div>
            <Button
              id="btn-create-order"
              onClick={() => setShowModal(true)}
              className="bg-emerald-600 hover:bg-emerald-700 text-white gap-2"
            >
              <Plus size={16} />
              Tạo đơn mới
            </Button>
          </div>

          <OrderTable orders={orders} />
        </div>
      </main>

      <NewOrderModal open={showModal} onClose={() => setShowModal(false)} />
    </>
  );
}
