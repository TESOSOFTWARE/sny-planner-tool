"use client";

import { notFound } from "next/navigation";
import { useOrders } from "@/lib/orderContext";
import { Topbar } from "@/components/layout/Topbar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { WarpingTable } from "@/components/orders/WarpingTable";
import { toVN, toVNDate } from "@/lib/formatters";
import { inventory } from "@/data/inventory";
import type { OrderStatus } from "@/types";
import { use } from "react";

const STATUS_COLORS: Record<OrderStatus, string> = {
  "Đang sản xuất": "bg-emerald-100 text-emerald-800 border-emerald-200",
  "Đã duyệt":       "bg-sky-100 text-sky-800 border-sky-200",
  "Chờ duyệt":      "bg-amber-100 text-amber-800 border-amber-200",
};

function SpecRow({ label, value }: { label: string; value: string | number | null }) {
  if (value === null || value === undefined) return null;
  return (
    <div className="flex items-center py-2 border-b border-slate-100 last:border-0">
      <dt className="w-36 text-sm text-slate-500 font-medium">{label}</dt>
      <dd className="text-sm font-mono text-slate-800">{String(value)}</dd>
    </div>
  );
}

interface PageProps {
  params: Promise<{ id: string }>;
}

export default function OrderDetailPage({ params }: PageProps) {
  const { id } = use(params);
  const decodedId = decodeURIComponent(id);
  const { orders } = useOrders();
  const order = orders.find((o) => o.id === decodedId);

  if (!order) return notFound();

  const { spec } = order;

  // Material needs tab: show a subset of inventory relevant to this order
  const materialRows = inventory.map((item) => {
    // Simulate a simple need calculation for demo purposes
    const need = order.meters * 0.0003 * (item.stock < 500 ? 1.5 : 0.8);
    const remaining = item.stock - item.committed;
    const shortage = Math.max(0, need - remaining);
    return { ...item, need: Math.round(need), remaining: Math.round(remaining), shortage: Math.round(shortage) };
  }).slice(0, 5); // Show top 5 for the demo

  return (
    <>
      <Topbar title={`Lệnh: ${order.id}`} />
      <main className="flex-1 p-6">
        <div className="max-w-5xl mx-auto space-y-5">
          {/* Header card */}
          <Card>
            <CardContent className="pt-5">
              <div className="flex flex-wrap gap-6">
                <div>
                  <p className="text-xs text-slate-500 mb-1">Mã đơn</p>
                  <p className="font-mono font-bold text-slate-800 text-lg">{order.id}</p>
                </div>
                <div>
                  <p className="text-xs text-slate-500 mb-1">Khách hàng</p>
                  <p className="font-semibold text-slate-800">{order.customer}</p>
                </div>
                <div>
                  <p className="text-xs text-slate-500 mb-1">Hạn giao</p>
                  <p className="font-semibold text-slate-800">{toVNDate(order.deadline)}</p>
                </div>
                <div>
                  <p className="text-xs text-slate-500 mb-1">Trạng thái</p>
                  <span
                    className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium ${STATUS_COLORS[order.status]}`}
                  >
                    {order.status}
                  </span>
                </div>
                <div>
                  <p className="text-xs text-slate-500 mb-1">Tổng mét</p>
                  <p className="font-mono font-semibold text-slate-800">{toVN(order.meters)} m</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Tabs */}
          <Tabs defaultValue="overview">
            <TabsList className="bg-slate-100">
              <TabsTrigger value="overview">Tổng quan</TabsTrigger>
              <TabsTrigger value="warping">Phiếu warping</TabsTrigger>
              <TabsTrigger value="materials">Nhu cầu nguyên liệu</TabsTrigger>
            </TabsList>

            {/* Tab 1: Overview */}
            <TabsContent value="overview" className="mt-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base text-slate-700">Quy cách sản phẩm</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="font-mono text-sm text-slate-500 mb-4 p-3 bg-slate-50 rounded-md border">
                    {order.specRaw}
                  </p>
                  <dl>
                    <SpecRow label="Loại lưới" value={spec.fabricType} />
                    <SpecRow label="GSM" value={spec.gsm} />
                    <SpecRow label="Màu" value={spec.color} />
                    <SpecRow label="Khổ (m)" value={spec.width} />
                    <SpecRow label="Dài cuộn (m)" value={spec.length} />
                    <SpecRow label="Số cuộn" value={spec.rolls} />
                    {spec.fr != null && <SpecRow label="%FR" value={`${spec.fr}%`} />}
                    {spec.uv != null && <SpecRow label="%UV" value={`${spec.uv}%`} />}
                  </dl>

                  <div className="mt-5 grid grid-cols-2 gap-4">
                    <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
                      <p className="text-xs text-slate-500 mb-1">Kế hoạch (m)</p>
                      <p className="font-mono font-bold text-slate-800 text-xl">
                        {toVN(order.meters)}
                      </p>
                    </div>
                    <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
                      <p className="text-xs text-slate-500 mb-1">Khối lượng ước tính (kg)</p>
                      <p className="font-mono font-bold text-slate-800 text-xl">
                        {spec.gsm && spec.width
                          ? toVN(Math.round((spec.gsm * spec.width * order.meters) / 1000))
                          : "—"}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Tab 2: Warping */}
            <TabsContent value="warping" className="mt-4">
              <WarpingTable color={spec.color ?? "NATURAL"} />
            </TabsContent>

            {/* Tab 3: Materials */}
            <TabsContent value="materials" className="mt-4">
              <div className="rounded-lg border border-slate-200 bg-white overflow-hidden">
                <div className="px-4 py-3 border-b border-slate-100 bg-slate-50">
                  <h3 className="text-sm font-semibold text-slate-700">
                    Nhu cầu nguyên liệu — {order.id}
                  </h3>
                </div>
                <Table>
                  <TableHeader>
                    <TableRow className="bg-slate-50 text-xs">
                      <TableHead className="font-semibold text-slate-600">Mã</TableHead>
                      <TableHead className="font-semibold text-slate-600">Tên</TableHead>
                      <TableHead className="font-semibold text-slate-600 text-right">Tồn kho</TableHead>
                      <TableHead className="font-semibold text-slate-600 text-right">Đã cam kết</TableHead>
                      <TableHead className="font-semibold text-slate-600 text-right">Còn lại</TableHead>
                      <TableHead className="font-semibold text-slate-600 text-right">Cần đặt</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {materialRows.map((row) => (
                      <TableRow
                        key={row.code}
                        className={row.shortage > 0 ? "bg-red-50 hover:bg-red-100" : "hover:bg-slate-50"}
                      >
                        <TableCell className="font-mono text-sm">{row.code}</TableCell>
                        <TableCell className="text-sm">{row.name}</TableCell>
                        <TableCell className="text-right font-mono text-sm">{toVN(row.stock)}</TableCell>
                        <TableCell className="text-right font-mono text-sm">{toVN(row.committed)}</TableCell>
                        <TableCell className="text-right font-mono text-sm">{toVN(row.remaining)}</TableCell>
                        <TableCell className={`text-right font-mono text-sm font-semibold ${row.shortage > 0 ? "text-red-700" : "text-slate-400"}`}>
                          {row.shortage > 0 ? toVN(row.shortage) : "—"}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </>
  );
}
