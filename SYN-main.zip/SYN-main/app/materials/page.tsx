"use client";

import { Topbar } from "@/components/layout/Topbar";
import { AlertCard } from "@/components/materials/AlertCard";
import { InventoryTable } from "@/components/materials/InventoryTable";
import { inventory } from "@/data/inventory";

export default function MaterialsPage() {
  return (
    <>
      <Topbar title="Cảnh báo nguyên liệu" />
      <main className="flex-1 p-6">
        <div className="max-w-5xl mx-auto space-y-6">
          <AlertCard />
          <InventoryTable items={inventory} />
        </div>
      </main>
    </>
  );
}
