import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Sidebar } from "@/components/layout/Sidebar";
import { OrderProvider } from "@/lib/orderContext";
import { TooltipProvider } from "@/components/ui/tooltip";

const inter = Inter({ subsets: ["latin", "vietnamese"] });

export const metadata: Metadata = {
  title: "SNY Planner — Hệ thống kế hoạch sản xuất",
  description: "Quản lý lệnh sản xuất, lịch máy dệt và nguyên liệu cho nhà máy SNY",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="vi">
      <body className={inter.className}>
        <OrderProvider>
          <TooltipProvider>
            <div className="flex min-h-screen bg-slate-50">
              <Sidebar />
              <div className="flex-1 ml-56 flex flex-col min-h-screen">
                {children}
              </div>
            </div>
          </TooltipProvider>
        </OrderProvider>
      </body>
    </html>
  );
}
