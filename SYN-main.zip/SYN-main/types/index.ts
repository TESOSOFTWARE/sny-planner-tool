// Shared types for SNY Planner demo

export type OrderStatus = "Đang sản xuất" | "Đã duyệt" | "Chờ duyệt";

export type FabricType =
  | "Shade Net"
  | "Windbreak"
  | "Rectangular"
  | "Fence"
  | "Leaf Net"
  | "Unknown";

export interface ParsedSpec {
  gsm: number | null;
  color: string | null;
  width: number | null;       // metres
  length: number | null;      // metres per roll
  rolls: number | null;
  fabricType: FabricType;
  fr: number | null;          // %FR
  uv: number | null;          // %UV
  raw: string;
}

export interface Order {
  id: string;                 // e.g. "FABO25044A"
  customer: string;
  specRaw: string;
  spec: ParsedSpec;
  meters: number;
  deadline: string;           // ISO date "YYYY-MM-DD"
  status: OrderStatus;
}

export interface Machine {
  id: number;
  name: string;               // "Máy 1"
  width: number;              // metres e.g. 6.85
}

export interface ScheduleCell {
  orderId: string;
  label: string;              // short label shown in cell
  tooltip: string;            // full spec shown on hover
  fabricType: FabricType;
  dayStart: number;
  dayEnd: number;
}

export interface MachineSchedule {
  machineId: number;
  cells: ScheduleCell[];
}

export interface ScheduleRevision {
  version: string;            // e.g. "5.1.2026"
  label: string;              // e.g. "5/1/2026"
  rows: MachineSchedule[];
}

export interface InventoryItem {
  code: string;
  name: string;
  type: string;               // "Masterbatch" | "Tape" etc.
  stock: number;              // kg in stock
  committed: number;          // kg committed to orders
}

export interface WarpingBeam {
  no: number;
  denier: number;
  strand: number;
  color: string;
  soMay: number;              // machine count
  soBim: number;
  bim: number;
  weightKg: number;
  viTri: "TRƯỚC" | "GIỮA" | "SAU";  // position
}
