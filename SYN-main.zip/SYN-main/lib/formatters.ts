/**
 * Format a number in Vietnamese locale:
 *   - Dot as thousands separator: 1.000
 *   - Comma as decimal separator: 4,5
 */
export function toVN(value: number, fractionDigits = 0): string {
  return new Intl.NumberFormat("vi-VN", {
    minimumFractionDigits: fractionDigits,
    maximumFractionDigits: fractionDigits,
  }).format(value);
}

/**
 * Format a date string (ISO "YYYY-MM-DD") to Vietnamese short date "DD/MM/YYYY"
 */
export function toVNDate(iso: string): string {
  const [y, m, d] = iso.split("-");
  return `${d}/${m}/${y}`;
}
