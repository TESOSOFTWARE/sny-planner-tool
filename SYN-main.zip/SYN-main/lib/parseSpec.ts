import type { ParsedSpec, FabricType } from "@/types";

/**
 * Derive fabric type from the raw spec string by scanning for known keywords.
 * Order matters: more specific phrases first.
 */
function deriveFabricType(raw: string): FabricType {
  const upper = raw.toUpperCase();
  if (upper.includes("LEAF NET")) return "Leaf Net";
  if (upper.includes("SHADE NET")) return "Shade Net";
  if (upper.includes("WINDBREAK")) return "Windbreak";
  if (upper.includes("RECTANGULAR")) return "Rectangular";
  if (upper.includes("FENCE")) return "Fence";
  // Heuristics for unlabelled specs
  if (upper.includes("KIWI")) return "Windbreak";
  return "Shade Net"; // most common default for this factory
}

/**
 * Extract the color token from the raw spec.
 *
 * Strategy:
 *  1. Strip leading GSM token (e.g. "220GSM")
 *  2. Strip trailing dimension block (e.g. "6MX100M 84ROLLS …")
 *  3. Strip %FR / %UV tokens
 *  4. What remains in the middle is the color.
 *
 * Handles multi-word colors like "SNOW WHITE" and "DARK GREEN".
 */
function extractColor(raw: string): string | null {
  let s = raw.trim();

  // Remove GSM prefix
  s = s.replace(/\d+(?:[.,]\d+)?\s*GSM\s*/i, "");

  // Remove %FR+%UV and similar
  s = s.replace(/\d+(?:[.,]\d+)?%FR\+\d+(?:[.,]\d+)?%UV/gi, "");
  s = s.replace(/\d+(?:[.,]\d+)?%FR/gi, "");
  s = s.replace(/\d+(?:[.,]\d+)?%UV/gi, "");

  // Remove parenthesised notes like "(390 needles)" or "(Single line Black double thread)"
  s = s.replace(/\(.*?\)/g, "");

  // Remove dimension + roll count block  e.g. "4008 6MX100M 84ROLLS 2LINE"
  // The "4008" is a numeric product code — treat as part of spec noise, not color
  s = s.replace(/\b\d{4}\b/g, "");                       // 4-digit codes e.g. 4008
  s = s.replace(/\d+(?:[.,]\d+)?MX\d+M\b/gi, "");        // WxL e.g. 6MX100M
  s = s.replace(/\d+ROLLS?\b/gi, "");                     // roll count
  s = s.replace(/\d+LINE\b/gi, "");                       // 2LINE / 3LINE
  s = s.replace(/\b\d+(?:[.,]\d+)?%\b/gi, "");           // stray percentages

  // Clean up and capitalise
  const color = s.trim().replace(/\s+/g, " ");
  return color.length > 0 ? color : null;
}

/**
 * parseSpec — pure function, no side effects.
 *
 * Accepts a raw spec string from the factory Excel (any of the 4 real formats)
 * and returns a fully typed ParsedSpec object.
 *
 * Examples that must parse correctly:
 *   "220GSM DGREEN 4008 6MX100M 84ROLLS"
 *   "170GSM SWHITE 1.6MX100M 85ROLLS (390 needles) 2LINE"
 *   "95GSM WHITE 6.5%FR+2%UV 3MX50M 400ROLLS 3LINE"
 *   "240GSM SNOW WHITE 4.5MX100M 38ROLLS (Single line Black double thread)"
 */
export function parseSpec(raw: string): ParsedSpec {
  if (!raw || !raw.trim()) {
    return {
      gsm: null, color: null, width: null, length: null,
      rolls: null, fabricType: "Unknown", fr: null, uv: null, raw,
    };
  }

  const upper = raw.toUpperCase();

  // GSM — always a number immediately before "GSM"
  const gsmMatch = raw.match(/(\d+(?:[.,]\d+)?)\s*GSM/i);
  const gsm = gsmMatch ? parseFloat(gsmMatch[1].replace(",", ".")) : null;

  // Width (Khổ) — number before "MX", e.g. 6MX or 1.6MX
  const widthMatch = raw.match(/(\d+(?:[.,]\d+)?)\s*MX/i);
  const width = widthMatch ? parseFloat(widthMatch[1].replace(",", ".")) : null;

  // Length (Dài cuộn) — number after "MX…M", e.g. 6MX100M → 100
  const lengthMatch = raw.match(/MX\s*(\d+(?:[.,]\d+)?)\s*M\b/i);
  const length = lengthMatch ? parseFloat(lengthMatch[1].replace(",", ".")) : null;

  // Rolls — number immediately before "ROLLS"
  const rollsMatch = raw.match(/(\d+)\s*ROLLS?/i);
  const rolls = rollsMatch ? parseInt(rollsMatch[1], 10) : null;

  // %FR — e.g. "6.5%FR"
  const frMatch = raw.match(/(\d+(?:[.,]\d+)?)\s*%FR/i);
  const fr = frMatch ? parseFloat(frMatch[1].replace(",", ".")) : null;

  // %UV — e.g. "2%UV"
  const uvMatch = raw.match(/(\d+(?:[.,]\d+)?)\s*%UV/i);
  const uv = uvMatch ? parseFloat(uvMatch[1].replace(",", ".")) : null;

  const color = extractColor(raw);
  const fabricType = deriveFabricType(upper);

  return { gsm, color, width, length, rolls, fabricType, fr, uv, raw };
}
