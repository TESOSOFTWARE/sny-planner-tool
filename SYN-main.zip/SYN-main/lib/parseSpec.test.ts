import { describe, it, expect } from "vitest";
import { parseSpec } from "./parseSpec";

describe("parseSpec", () => {
  it("parses shade-net mono spec", () => {
    const result = parseSpec("220GSM DGREEN 4008 6MX100M 84ROLLS");
    expect(result.gsm).toBe(220);
    expect(result.color).toBe("DGREEN");
    expect(result.width).toBe(6);
    expect(result.length).toBe(100);
    expect(result.rolls).toBe(84);
    expect(result.fr).toBeNull();
    expect(result.uv).toBeNull();
  });

  it("parses spec with needle count and 2LINE suffix", () => {
    const result = parseSpec("170GSM SWHITE 1.6MX100M 85ROLLS (390 needles) 2LINE");
    expect(result.gsm).toBe(170);
    expect(result.color).toBe("SWHITE");
    expect(result.width).toBe(1.6);
    expect(result.length).toBe(100);
    expect(result.rolls).toBe(85);
  });

  it("parses spec with %FR and %UV", () => {
    const result = parseSpec("95GSM WHITE 6.5%FR+2%UV 3MX50M 400ROLLS 3LINE");
    expect(result.gsm).toBe(95);
    expect(result.color).toBe("WHITE");
    expect(result.width).toBe(3);
    expect(result.length).toBe(50);
    expect(result.rolls).toBe(400);
    expect(result.fr).toBe(6.5);
    expect(result.uv).toBe(2);
  });

  it("parses multi-word color with parenthesised note", () => {
    const result = parseSpec(
      "240GSM SNOW WHITE 4.5MX100M 38ROLLS (Single line Black double thread)"
    );
    expect(result.gsm).toBe(240);
    expect(result.color).toBe("SNOW WHITE");
    expect(result.width).toBe(4.5);
    expect(result.length).toBe(100);
    expect(result.rolls).toBe(38);
  });

  it("returns nulls for empty string", () => {
    const result = parseSpec("");
    expect(result.gsm).toBeNull();
    expect(result.color).toBeNull();
  });

  it("returns Unknown fabric type when no keyword found", () => {
    const result = parseSpec("100GSM RED 2MX50M 100ROLLS");
    // No explicit keyword → defaults to Shade Net heuristic
    expect(result.fabricType).toBe("Shade Net");
  });
});
