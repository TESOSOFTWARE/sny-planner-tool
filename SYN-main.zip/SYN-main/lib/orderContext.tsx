"use client";

import React, { createContext, useContext, useReducer, useCallback } from "react";
import type { Order } from "@/types";
import { initialOrders } from "@/data/orders";
import { parseSpec } from "@/lib/parseSpec";

// ─── State ────────────────────────────────────────────────────────────────────

interface OrderState {
  orders: Order[];
}

type OrderAction =
  | { type: "ADD_ORDER"; payload: { specRaw: string; customer: string; deadline: string } };

function ordersReducer(state: OrderState, action: OrderAction): OrderState {
  switch (action.type) {
    case "ADD_ORDER": {
      const id = `NEW-${Date.now().toString(36).toUpperCase()}`;
      const newOrder: Order = {
        id,
        customer: action.payload.customer || "Khách mới",
        specRaw: action.payload.specRaw,
        spec: parseSpec(action.payload.specRaw),
        meters:
          (() => {
            const s = parseSpec(action.payload.specRaw);
            return (s.rolls ?? 1) * (s.length ?? 0);
          })(),
        deadline: action.payload.deadline,
        status: "Chờ duyệt",
      };
      return { orders: [newOrder, ...state.orders] };
    }
    default:
      return state;
  }
}

// ─── Context ──────────────────────────────────────────────────────────────────

interface OrderContextValue {
  orders: Order[];
  addOrder: (specRaw: string, customer: string, deadline: string) => string;
  getOrder: (id: string) => Order | undefined;
}

const OrderContext = createContext<OrderContextValue | null>(null);

export function OrderProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(ordersReducer, { orders: initialOrders });

  const addOrder = useCallback(
    (specRaw: string, customer: string, deadline: string): string => {
      dispatch({ type: "ADD_ORDER", payload: { specRaw, customer, deadline } });
      // Return the generated ID pattern so we can navigate to it
      return `NEW-${Date.now().toString(36).toUpperCase()}`;
    },
    []
  );

  const getOrder = useCallback(
    (id: string) => state.orders.find((o) => o.id === id),
    [state.orders]
  );

  return (
    <OrderContext.Provider value={{ orders: state.orders, addOrder, getOrder }}>
      {children}
    </OrderContext.Provider>
  );
}

export function useOrders() {
  const ctx = useContext(OrderContext);
  if (!ctx) throw new Error("useOrders must be used inside OrderProvider");
  return ctx;
}
